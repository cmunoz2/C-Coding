//Cesar Munoz FINAL
// c++
// 2018

// repl.it started diplaying outputs twice including player input. Along with a message from the site telling me my .cpp has changed on the remote disk with the option to update my content! Everything seems to run normally still, however. 

//[X]=INCOMPLETE  [O]=COMPLETE

//V1 - Adding VERB_ACTION --> GET [O]
//V2 - Added inventory system (For the BOW and BOOMERANG!) [O]
//V3 - Added DROP mechanic [X] 
//V4 - Added USE mechanic [O]
//V5 - Made it Zelda themed [O]
//V6 - Made struct words to class [O]
//V7 - Made struct room to class [O]
//V8 - Made struct noun to class [O]
//V9 - 

#include <iostream>
#include <string>
#include <vector>
#include <cctype>

using namespace std;

enum en_DIRS {NORTH, EAST, SOUTH, WEST};
enum en_ROOMS {HUT, INN, WOODS, CASTLE, VILLAGE, LAKE, FAIRYFOUNTAIN, DESSERT, PLATEAU, MOUNTAIN, CAVE};
enum en_VERBS {GET, DROP, USE, OPEN, CLOSE, EXAMINE, INVENTORY, LOOK};

//Added code
enum en_NOUNS {BOMB_WALL, BOOMERANG, BATS, MINIGAME, BOW, FISHROD};
//MASTER_SWORD, ADULT_WALLET, TRIFORCE, BOTTLE, HOOKSHOT, OCARINA, NAVI, STABLE, SHEILD
//...

const int NONE = -1;
const int DIRS = 4;
const int ROOMS = 11;
const int VERBS = 8;

//Added code
const int NOUNS = 6;
//...

//Inventory
vector<string>playerInventory;
vector<string>::iterator iter;
//Drop
string dropInput = " ";

static bool BOW_state = false; //False is coins not picked up yet.
static bool BOOMERANG_state = false; //False is BOOMERANG not picked up yet.

class words
{
public:

  string word;
  int code;

};
class room
{
  public:
  string description;
  int exits_to_room[DIRS];
};

//Added code 
class noun
{
  public:
  string word;
  string description;
  int code;
  int location;
  bool can_carry;
};
//...




//--------------------------------

void set_rooms(room *rms)
{
  rms[HUT].description.assign("minigame hut");
  rms[HUT].exits_to_room[NORTH]= NONE;
  rms[HUT].exits_to_room[EAST]= NONE;
  rms[HUT].exits_to_room[SOUTH]= WOODS;
  rms[HUT].exits_to_room[WEST]= NONE;

  rms[INN].description.assign("bustling inn");
  rms[INN].exits_to_room[NORTH] = NONE;
  rms[INN].exits_to_room[EAST] = NONE;
  rms[INN].exits_to_room[SOUTH] = CASTLE;
  rms[INN].exits_to_room[WEST] = NONE;

  rms[WOODS].description.assign("lost woods");
  rms[WOODS].exits_to_room[NORTH] = HUT;
  rms[WOODS].exits_to_room[EAST] = CASTLE;
  rms[WOODS].exits_to_room[SOUTH] = NONE;
  rms[WOODS].exits_to_room[WEST] = NONE;

  rms[CASTLE].description.assign("hyrule castle");
  rms[CASTLE].exits_to_room[NORTH] = INN;
  rms[CASTLE].exits_to_room[EAST] = VILLAGE;
  rms[CASTLE].exits_to_room[SOUTH] = LAKE;
  rms[CASTLE].exits_to_room[WEST] = WOODS;

  rms[VILLAGE].description.assign("kakariko village");
  rms[VILLAGE].exits_to_room[NORTH] = NONE;
  rms[VILLAGE].exits_to_room[EAST] = NONE;
  rms[VILLAGE].exits_to_room[SOUTH] = NONE;
  rms[VILLAGE].exits_to_room[WEST] = CASTLE;

  rms[LAKE].description.assign("lake hylia");
  rms[LAKE].exits_to_room[NORTH] = CASTLE;
  rms[LAKE].exits_to_room[EAST] = NONE;
  rms[LAKE].exits_to_room[SOUTH] = PLATEAU;
  rms[LAKE].exits_to_room[WEST] = NONE;

  rms[FAIRYFOUNTAIN].description.assign("great fairy fountain");
  rms[FAIRYFOUNTAIN].exits_to_room[NORTH] = NONE;
  rms[FAIRYFOUNTAIN].exits_to_room[EAST] = NONE;
  rms[FAIRYFOUNTAIN].exits_to_room[SOUTH] = NONE;
  rms[FAIRYFOUNTAIN].exits_to_room[WEST] = NONE;

  rms[DESSERT].description.assign("gerudo dessert");
  rms[DESSERT].exits_to_room[NORTH] = NONE;
  rms[DESSERT].exits_to_room[EAST] = PLATEAU;
  rms[DESSERT].exits_to_room[SOUTH] = CAVE;
  rms[DESSERT].exits_to_room[WEST] = NONE;

  rms[PLATEAU].description.assign("great plateau");
  rms[PLATEAU].exits_to_room[NORTH] = LAKE;
  rms[PLATEAU].exits_to_room[EAST] = MOUNTAIN;
  rms[PLATEAU].exits_to_room[SOUTH] = NONE;
  rms[PLATEAU].exits_to_room[WEST] = DESSERT;

  rms[MOUNTAIN].description.assign("death mountain");
  rms[MOUNTAIN].exits_to_room[NORTH] = NONE;
  rms[MOUNTAIN].exits_to_room[EAST] = NONE;
  rms[MOUNTAIN].exits_to_room[SOUTH] = NONE;
  rms[MOUNTAIN].exits_to_room[WEST] = PLATEAU;

  rms[CAVE].description.assign("old cave");
  rms[CAVE].exits_to_room[NORTH] = DESSERT;
  rms[CAVE].exits_to_room[EAST] = NONE;
  rms[CAVE].exits_to_room[SOUTH] = NONE;
  rms[CAVE].exits_to_room[WEST] = NONE;
}

//--------------------------------

void set_direction(words *dir)
{
  dir[NORTH].code = NORTH;
  dir[NORTH].word = "NORTH";
  dir[EAST].code = EAST;
  dir[EAST].word = "EAST";
  dir[SOUTH].code = SOUTH;
  dir[SOUTH].word = "SOUTH";
  dir[WEST].code = WEST;
  dir[WEST].word = "WEST";
}

//--------------------------------

void set_verbs(words *vbs)
{
  //enum en_VERBS {GET, DROP, USE, OPEN, CLOSE, EXAMINE, //INVENTORY, LOOK};
  vbs[GET].code = GET;
  vbs[GET].word = "GET";
  vbs[DROP].code = DROP;
  vbs[DROP].word = "DROP";
  vbs[USE].code = USE;
  vbs[USE].word = "USE";
  vbs[OPEN].code = OPEN;
  vbs[OPEN].word = "OPEN";
  vbs[CLOSE].code = CLOSE;
  vbs[CLOSE].word = "CLOSE";
  vbs[EXAMINE].code = EXAMINE;
  vbs[EXAMINE].word = "EXAMINE";
  vbs[INVENTORY].code = INVENTORY;
  vbs[INVENTORY].word = "INVENTORY";
  vbs[LOOK].code = LOOK;
  vbs[LOOK].word = "LOOK";
}
  
//--------------------------------

//Added code
void set_nouns(noun *nns)
{
  //enum en_NOUNS {BOMB_WALL, BOOMERANG, BATS, MINIGAME, //BOW, FISHROD};
  nns[BOMB_WALL].word = "WALL";
  nns[BOMB_WALL].code = BOMB_WALL;
  nns[BOMB_WALL].description = "a cracked wall";
  nns[BOMB_WALL].can_carry = false;
  nns[BOMB_WALL].location = LAKE;
  nns[BOOMERANG].word = "BOOMERANG";
  nns[BOOMERANG].code = BOOMERANG;
  nns[BOOMERANG].description = "a BOOMERANG";
  nns[BOOMERANG].can_carry = true;
  nns[BOOMERANG].location = CAVE;
  nns[BATS].word = "BATS";
  nns[BATS].code = BATS;
  nns[BATS].description = " BATS";
  nns[BATS].can_carry = false;
  nns[BATS].location = WOODS;
  nns[MINIGAME].word = "MINIGAME";
  nns[MINIGAME].code = MINIGAME;
  nns[MINIGAME].description = "a MINIGAME wheel";
  nns[MINIGAME].can_carry = false;
  nns[MINIGAME].location = INN;
  nns[BOW].word = "BOW";
  nns[BOW].code = BOW;
  nns[BOW].description = "a BOW";
  nns[BOW].can_carry = true;
  nns[BOW].location = FAIRYFOUNTAIN;
  nns[FISHROD].word = "ROD";
  nns[FISHROD].code = FISHROD;
  nns[FISHROD].description = "a fishing rod";
  nns[FISHROD].can_carry = false;
  nns[FISHROD].location = HUT;
  nns[BOMB_WALL].word = "WALL";
  nns[BOMB_WALL].code = BOMB_WALL;
  nns[BOMB_WALL].description = "a cracked wall";
  nns[BOMB_WALL].can_carry = false;
  nns[BOMB_WALL].location = LAKE;
}

//--------------------------------

void section_command(string Cmd, string &wd1, string &wd2)
{
  string sub_str;
  vector<string> words;
  char search = ' ';
  size_t i, j;

  for(i = 0; i < Cmd.size(); i++)
  {
    if (Cmd.at(i) != search)
    {
      sub_str.insert(sub_str.end(), Cmd.at(i));
    }
    if (i == Cmd.size()-1)
    {
      words.push_back (sub_str);
      sub_str.clear();
    }
    if(Cmd.at(i) == search)
    {
      words.push_back(sub_str);
      sub_str.clear();
    }
  }

  for(i = words.size() - 1; i > 0; i--)
  {
    if(words.at(i) == "")
    {
      words.erase(words.begin() + i);
    }
  }
    
  for (i = 0; i<words.size(); i++)
  {
    for(j=0; j<words.at(i).size(); j++)
    {
      if(islower(words.at(i).at(j)))
      {
        words.at(i).at(j) = toupper(words.at(i).at(j));
      }
    }
  }

  if(words.size() == 0)
  {
    cout<< "No command given";
  }
  if(words.size() == 1)
  {
    wd1 = words.at(0);
  }
  if(words.size() == 2)
  {
    wd1 = words.at(0);
    wd2 = words.at(1); 
  }
  if(words.size() >2)
  {
    cout<<"\nCommand too long. Only type one or two words (direction or verb and noun)\n";
  }
}

//--------------------------------

// No changes to look_around
void look_around(int loc, room *rms, words * dir, /* Added paraBATS */ noun *nns)
{
  int i;
  cout<<"\nI am in a "<<rms[loc].description<<".\n";

  for(i =0; i<DIRS; i++)
  {
    if(rms[loc].exits_to_room[i] != NONE)
    {
      cout<<"There is an exit "<<dir[i].word<<" to a "<<rms[rms[loc].exits_to_room[i]].description<<".";
    }
  }

  //Added code 
  //The look commands should check which objects (nouns) 
  //are in the current room and report them to the player

  for(i =0;i<NOUNS;i++)
  {
    if(nns[i].location == loc)
    {
      cout<<"I see "<< nns[i].description<<".";
    }
  }
}

//--------------------------------

void view_inventory()
{

  for(iter = playerInventory.begin(); iter != playerInventory.end(); iter++)
  cout << *iter << " ";
}

//--------------------------------
//DROP FUCNTION UNSUCCESSFULL. Terminates program 
//void drop_item()
//{
//  cout<<"What should I drop?";
//  cin>> dropInput;
//  cout<<dropInput;
//  if (BOW_state == true && dropInput =="BOW")
//  {
//    
//    playerInventory[0] = " ";
//    BOW_state = false;
//  }
//  if(BOOMERANG_state == true && dropInput == "BOOMERANG")
//  {
//    playerInventory[1] = "";
//    BOOMERANG_state = false;
//  }
//  else
//  {
//    cout<<"\nInput not understood";
// }
//}

//--------------------------------

//No changes to parser
bool parser(int &loc, string wd1, string wd2, words *dir, words *vbs, room *rms, noun *nns)
{
  static bool door_state = false; //False is a closed door.




  int i;
  for(i = 0; i< DIRS; i++)
  {
    if(wd1 == dir[i].word)
    {
      if(rms[loc].exits_to_room[dir[i].code] != NONE)
      {
        loc = rms[loc].exits_to_room[dir[i].code];
        cout<< "\nI am now in a "<<rms[loc].description<<".";
        if(loc == FAIRYFOUNTAIN || loc == LAKE)
        {
          nns[BOMB_WALL].location = loc;
        }
        return true;
      }
      else 
      {
        cout<<"No exit that way.\n";
        return true;
      }
    }
  }
  int NOUN_MATCH = NONE;
  int VERB_ACTION = NONE;

  for(i = 0; i<VERBS; i++)
  {
    if(wd1 == vbs[i].word)
    {
      VERB_ACTION = vbs[i].code;
      break;
    }
  }
  if(wd2 != "")
  {
    for(i=0;i<NOUNS; i++)
    {
      if(wd2 == nns[i].word)
      {
        NOUN_MATCH = nns[i].code;
        break;
      }
    }
  }


  //Verb actions
  if(VERB_ACTION == INVENTORY)
  {
    view_inventory();
  }

  //if(VERB_ACTION == DROP)
  //{
  //  drop_item();
  //}

  if(VERB_ACTION == USE)
  {
    int pkMtr = 0;
    int rlttbl = 0;
    if(NOUN_MATCH == BATS)
    {
      if(pkMtr==0 && loc ==WOODS && BOW_state== true)
      {
        pkMtr++;
        cout<<"I shoot the BATS with my BOW.";
        playerInventory[0]="  ";
        
      }
      //Couldnt get the "Item was used" to work
      //if (pkMtr != 0)
      //{
      //  cout<<"I already used this.";
      //}
    }
    if(NOUN_MATCH == MINIGAME)
    {
      if(rlttbl==0 && loc ==INN && BOOMERANG_state== true)
      {
        rlttbl++;
        cout<<"I used the BOOMERANG to cheat at the game... I hope no one notices.";
        playerInventory[1] = " ";
      }
      //if (rlttbl != 0)
      //{
      //  cout<<"I already used this.";
      //}
    }
  }

  if(VERB_ACTION == LOOK)
  {
    look_around(loc, rms, dir, nns);
    return true; 
  }

  if(VERB_ACTION == OPEN)
  {
    if(NOUN_MATCH == BOMB_WALL)
    {
      if(loc == LAKE || loc == FAIRYFOUNTAIN)
      {
        if(door_state == false)
        {
          door_state = true;
          rms[LAKE].exits_to_room[EAST] = FAIRYFOUNTAIN;
          rms[FAIRYFOUNTAIN].exits_to_room[WEST] = LAKE;
          nns[BOMB_WALL].description.clear();
          nns[BOMB_WALL].description.assign("an opened wall");
          cout<<"\nBOOM! I made an enterance.\n";
          return true;
        }
        else if(door_state == true)
        {
          cout<<"\nThe wall is already open.\n";
          return true;
        }
      }
      else 
      {
        cout<<"\nThere is no wall to open here.\n";
        return true;
      }
    }
    else 
    {
      cout<<"\nOpening that is not possible.\n";
      return true;
    }
    return false;
  }
  
  if (VERB_ACTION == GET)
  {
    if(NOUN_MATCH == BOW)
    {
      if(loc == FAIRYFOUNTAIN)
      {
        if(BOW_state == false)
        {
          BOW_state = true;
          playerInventory[0]="BOW";
          cout<<"I picked up a BOW. I can use it to fight the BATS now.";
          return true;
        }
        else if(BOW_state == true)
        {
          cout<<"I already took the BOW from this room.";
          return true;
        }
      }
      else 
      {
        cout<<" There is no BOW here to grab.";
        return true;
      }
      return false;
    } 
    
    if (NOUN_MATCH == BOOMERANG)
    {
      if(loc == CAVE)
      {
        if(BOOMERANG_state == false)
        {
          BOOMERANG_state = true;
          playerInventory[1] = "BOOMERANG";
          cout<<"I picked up a BOOMERANG.";
          return true;
        }
        else if(BOOMERANG_state == true)
        {
          cout<<"I already picked up the BOOMERANG from here.";
          return true;
        }
      }
      else
      {
        cout<<"There is no BOOMERANG here.";
        return true;
      }
      return false;
    }
  }
  return false;
}


//--------------------------------
//--------------------------------
//--------------------------------

int main()
{
  //Place holders for BOW and BOOMERANG
  playerInventory.push_back(" ");     //0 placeholder
  playerInventory.push_back("  ");    //1 placeholder

  string command;
  string word_1;
  string word_2;

  room rooms[ROOMS];
  set_rooms(rooms);

  words directions[DIRS];
  set_direction(directions);

  words verbs[VERBS];
  set_verbs(verbs);

  noun nouns[NOUNS];
  set_nouns(nouns);


  int location = WOODS;

  while(word_1 != "QUIT")
  {
    command.clear();
    cout<<"\nWhat shall I do?";
    getline(cin, command);

    word_1.clear();
    word_2.clear();

    section_command(command, word_1, word_2);

    if(word_1 != "QUIT")
    {
      parser(location, word_1, word_2, directions, verbs, rooms, nouns);
    }
  }
  return 0;
}