//Cesar Munoz
//C++ Midterm 
// Random outcome simulator, rolls and luck lead 
// players to the end of the game.
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdlib>

using namespace std;

int roll();
char meet();
bool move();

static const vector <string> fantasy();

int main()
{  
  srand(static_cast<unsigned int>(time(0))); 
  int randomNumber = rand(); 

  vector<string> fates;
  fates.push_back("BEEEES!!!");
  fates.push_back("Stubbed toe!");
  fates.push_back("Saw a sad documentary about whales.");
  fates.push_back("VERY bad WiFi.");
  fates.push_back("Poured cereal but forgot there is no milk...");
  fates.push_back("Slept through BOTH alarms!");
  fates.push_back("Forgot favorite evil slaying sword at home.");

  string player_name = "hhhll";
  cout<< "What is your name?";
  cin>>player_name;

  int turns = 0;
  bool keepPlaying;
  keepPlaying = true;

  cout<<player_name<< ", Welcome to <MIDTERM>";
  cout<<player_name<< "Is lost in the wilderness, and they need to find a way out!";
  
  while ((keepPlaying = true) && (turns <= 5))
    turns ++;
    cout<<"Would you like to go North, East, South, or West?";
    cin>>move;
    roll();
    if die >= 19
    {
      cout<<"You did it flawlessly, you escaped and with lots of loot!"
      return false;
    }
    else die > 5
    {
      cout<<"You are still lost!"
      roll();
        if die > 10
        meet();
      return true;
    }
    else 
    {
      cout<<player_name<<" meets a horrible fate! and blacks out.";
      return false;
    }
    if turns >= 5
    {
      cout<<"You made it by the skin of your teeth!"
      return false;
    }
 cout<<"Thank you for playing!!"
}

//functions
int roll()
{
   int die = (randomNumber % 20) + 1;
    cout<<" You rolled "<<die<<endl;
}
char meet()
{
     string <vector> fantasy
     fantasy random_element(fantasy begin, fantasy end)
  {
    const unsigned long n = distance(begin, end);
    const unsigned long divisor = (RAND_MAX + 1) / n;

    unsigned long k;
    do { k = rand() / divisor; } while (k >= n);

    advance(begin, k);
    return begin;
  }
  cout<<player_name<<"meets"<<___;
}